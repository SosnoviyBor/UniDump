MYSQL_CREDENTIALS = {
    "host": "",
    "user": "",
    "password": ""
}

# https://www.mongodb.com/docs/manual/reference/connection-string/
MONGO_CREDENTIALS = "mongodb+srv://user:pass@cluster.mongodb.net/myFirstDatabase"